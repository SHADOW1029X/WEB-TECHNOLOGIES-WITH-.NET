﻿using System.ComponentModel.DataAnnotations;

namespace ExpenseTracker.Models
{
    public class Budget
    {
        public int BudgetId { get; set; }

        [Required]
        public decimal MonthlyLimit { get; set; }  

        public int UserId { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
    }
}
