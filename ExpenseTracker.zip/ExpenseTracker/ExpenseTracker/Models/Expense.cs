﻿using System.ComponentModel.DataAnnotations;

namespace ExpenseTracker.Models
{
    public class Expense
    {
        public int ExpenseId { get; set; }

        [Required]
        public string Title { get; set; } = string.Empty;

        [Required]
        public decimal Amount { get; set; }

        // ✅ Change property name to ExpenseDate (so that it matches your code)
        public DateTime ExpenseDate { get; set; } = DateTime.Now;

        public string Notes { get; set; } = string.Empty;

        public int UserId { get; set; }
        public User? User { get; set; }

        public int CategoryId { get; set; }
        public Category? Category { get; set; }
    }
}
