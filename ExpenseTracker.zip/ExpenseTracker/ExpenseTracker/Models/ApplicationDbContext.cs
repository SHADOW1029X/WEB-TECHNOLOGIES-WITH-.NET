﻿using Microsoft.EntityFrameworkCore;

namespace ExpenseTracker.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Expense> Expenses { get; set; }
        public DbSet<Budget> Budgets { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, CategoryName = "Food", Description = "Meals & groceries" },
                new Category { CategoryId = 2, CategoryName = "Travel", Description = "Transport & trips" },
                new Category { CategoryId = 3, CategoryName = "Bills", Description = "Utilities & subscriptions" },
                new Category { CategoryId = 4, CategoryName = "Shopping", Description = "Clothes & items" },
                new Category { CategoryId = 5, CategoryName = "Health", Description = "Medical & fitness" }
            );
        }
    }
}
