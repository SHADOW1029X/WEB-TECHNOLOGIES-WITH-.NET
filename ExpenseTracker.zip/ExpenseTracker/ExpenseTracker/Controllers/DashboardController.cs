﻿using Microsoft.AspNetCore.Mvc;
using ExpenseTracker.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace ExpenseTracker.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;
        public DashboardController(ApplicationDbContext context) => _context = context;

        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            var now = DateTime.Now;
            var monthlyExpenses = _context.Expenses
                .Include(e => e.Category)
                .Where(e => e.UserId == userId.Value && e.ExpenseDate.Month == now.Month && e.ExpenseDate.Year == now.Year)
                .ToList();

            ViewBag.TotalSpent = monthlyExpenses.Sum(e => e.Amount);

            var budget = _context.Budgets.FirstOrDefault(b => b.UserId == userId.Value && b.Month == now.Month && b.Year == now.Year);
            if (budget != null && ViewBag.TotalSpent > budget.MonthlyLimit)
                ViewBag.BudgetAlert = "⚠️ You have exceeded your monthly budget limit!";

            var categorySummary = monthlyExpenses
                .GroupBy(e => e.Category.CategoryName)
                .Select(g => new { Category = g.Key, Total = g.Sum(e => e.Amount) })
                .ToList();

            ViewBag.CategorySummary = categorySummary;

            // simple daily totals for chart (last 30 days)
            var last30 = Enumerable.Range(0, 30)
                .Select(i => now.Date.AddDays(-i))
                .Reverse()
                .ToList();

            var daily = last30.Select(d => new {
                Date = d.ToString("yyyy-MM-dd"),
                Total = _context.Expenses
                            .Where(e => e.UserId == userId.Value && e.ExpenseDate.Date == d)
                            .Sum(e => (decimal?)e.Amount) ?? 0m
            }).ToList();

            ViewBag.DailyTotals = daily;

            return View();
        }
    }
}
