﻿using Microsoft.AspNetCore.Mvc;
using ExpenseTracker.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace ExpenseTracker.Controllers
{
    public class ExpenseController : Controller
    {
        private readonly ApplicationDbContext _context;
        public ExpenseController(ApplicationDbContext context) => _context = context;

        // -------------------- INDEX --------------------
        public IActionResult Index(string search, int? categoryId, DateTime? fromDate, DateTime? toDate)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            var query = _context.Expenses
                .Include(e => e.Category)
                .Where(e => e.UserId == userId.Value)
                .AsQueryable();

            if (!string.IsNullOrEmpty(search))
                query = query.Where(e => e.Title.Contains(search) || e.Notes.Contains(search));

            if (categoryId.HasValue && categoryId.Value > 0)
                query = query.Where(e => e.CategoryId == categoryId.Value);

            if (fromDate.HasValue)
                query = query.Where(e => e.ExpenseDate >= fromDate.Value.Date);

            if (toDate.HasValue)
                query = query.Where(e => e.ExpenseDate <= toDate.Value.Date);

            var list = query.OrderByDescending(e => e.ExpenseDate).ToList();
            ViewBag.Categories = _context.Categories.ToList();
            return View(list);
        }

        // -------------------- CREATE (GET) --------------------
        public IActionResult Create()
        {
            ViewBag.Categories = _context.Categories.ToList();
            return View(new Expense { ExpenseDate = DateTime.Now });
        }

        // -------------------- CREATE (POST) --------------------
        [HttpPost]
        public IActionResult Create(Expense expense)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = _context.Categories.ToList();
                return View(expense);
            }

            expense.UserId = userId.Value;
            _context.Expenses.Add(expense);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        // -------------------- EDIT (GET) --------------------
        public IActionResult Edit(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            var expense = _context.Expenses.FirstOrDefault(e => e.ExpenseId == id && e.UserId == userId.Value);
            if (expense == null) return NotFound();

            ViewBag.Categories = _context.Categories.ToList();
            return View(expense);
        }

        // -------------------- EDIT (POST) --------------------
        [HttpPost]
        public IActionResult Edit(Expense expense)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = _context.Categories.ToList();
                return View(expense);
            }

            var existingExpense = _context.Expenses.FirstOrDefault(e => e.ExpenseId == expense.ExpenseId && e.UserId == userId.Value);
            if (existingExpense == null) return NotFound();

            // Update fields
            existingExpense.Title = expense.Title;
            existingExpense.Amount = expense.Amount;
            existingExpense.CategoryId = expense.CategoryId;
            existingExpense.ExpenseDate = expense.ExpenseDate;
            existingExpense.Notes = expense.Notes;

            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        // -------------------- DELETE --------------------
        public IActionResult Delete(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "Account");

            var expense = _context.Expenses.FirstOrDefault(e => e.ExpenseId == id && e.UserId == userId.Value);
            if (expense != null)
            {
                _context.Expenses.Remove(expense);
                _context.SaveChanges();
            }

            return RedirectToAction("Index");
        }
    }
}
